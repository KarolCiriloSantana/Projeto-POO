package Interfaces;

public class InterfaceAluno {
    
}
