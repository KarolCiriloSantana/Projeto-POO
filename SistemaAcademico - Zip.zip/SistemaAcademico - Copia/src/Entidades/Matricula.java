package Entidades;

public class Matricula {
    
}
